def plusone(_number):
    return _number + 1
